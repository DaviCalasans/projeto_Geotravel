// Seleciona os botões e imagens
const btnCurtir = document.getElementById("btn-curtir");
const btnComentar = document.getElementById("btn-comentar");
const btnSalvar = document.getElementById("btn-salvar");

const imgCurtir = document.getElementById("curtirNA");
const imgComentar = document.getElementById("comentNA");
const imgSalvar = document.getElementById("salvarNA");

// Alterna o estado do botão de curtir
btnCurtir.addEventListener("click", () => {
    if (imgCurtir.src.includes("curtir.png")) {
        imgCurtir.src = "../imgs/curtirImg.png"; // Imagem para "curtido"
    } else {
        imgCurtir.src = "../imgs/curtir.png"; // Imagem para "não curtido"
    }
});

// Alterna o estado do botão de salvar
btnSalvar.addEventListener("click", () => {
    if (imgSalvar.src.includes("salvar.png")) {
        imgSalvar.src = "../imgs/salvarImg.png"; // Imagem para "salvo"
    } else {
        imgSalvar.src = "../imgs/salvar.png"; // Imagem para "não salvo"
    }
});