const comunidadesSugeridas = document.getElementsByClassName('sugestao-comunidades');
const btnComunidades = document.getElementById('btn-comunidades');

function abrirComunidades(){
    comunidadesSugeridas.style.display = 'block';
}