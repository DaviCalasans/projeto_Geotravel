function validar(){
    email = loginForm.emailUser;
    senha = loginForm.passwordUser;
    
    if(email.value == ""){
        alert("Preencha o campo de email")
    }else if(senha.value == ""){
        alert("Preencha o campo de senha")
    }else{
        alert("Usuário autenticado!")
        window.location.href = "../html/feedPage.html"
    }
}